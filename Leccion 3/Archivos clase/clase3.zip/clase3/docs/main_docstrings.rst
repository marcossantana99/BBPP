main\_docstrings module
=======================

.. automodule:: main_docstrings
   :members:
   :undoc-members:
   :show-inheritance:
