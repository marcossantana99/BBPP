ejemplo\_docstring module
=========================

.. automodule:: ejemplo_docstring
   :members:
   :undoc-members:
   :show-inheritance:
