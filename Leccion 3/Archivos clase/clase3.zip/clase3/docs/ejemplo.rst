ejemplo module
==============

.. automodule:: ejemplo
   :members:
   :undoc-members:
   :show-inheritance:
