def square(a):
    '''Returned argument a is squared.'''
    return a**a


#print (square.__doc__)
#help(square)

def some_function(argument1):
    """Summary or Description of the Function

    Parameters:
    argument1 (int): Description of arg1

    Returns:
    int:Returning value

   """

    return argument1


#print (some_function.__doc__)
#help(some_function)

import math
#print(math.__doc__)
#help(math)
